﻿using StackUnderflow.DatabaseModel.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace StackUnderflow.Domain.Core.Contexts.Question
{
    public class WriteContext
    {
       /* public ICollection<QuestionDB> Questions { get; }
        public WriteContext(ICollection<QuestionDB> questions)
        {
            Questions = questions ?? new List<QuestionDB>();
        }*/
    }
}
