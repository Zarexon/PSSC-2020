﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Access.Primitives.IO.Extensions.xUnit
{
    public enum Idempotency
    {
        RunOnce,
        RunTwice
    }
}
