﻿CREATE USER [AppUser]
	FOR LOGIN [AppUser]

GO

GRANT CONNECT TO [AppUser]
Go