﻿CREATE LOGIN [AppUser] WITH PASSWORD = 'E+|eBOjIe wa>zfleza|uaXImsFT7_&#$!~<vdwgjn,xram9'
